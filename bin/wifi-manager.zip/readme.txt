Openwrt thread:
https://forum.openwrt.org/viewtopic.php?id=43352


##################
#  INSTALLATION  #
##################
==================================================================

Create the folder:

mkdir /etc/wifiMgr


Copy the files as this:
config          /etc/wifiMgr
wifiMgr.sh      /usr/bin
wifiMgr	        /etc/init.d

Then execute this commands:

chmod 777 /usr/bin/wifiMgr.sh
chmod 777 /etc/init.d/wifiMgr
chmod 777 /etc/wifiMgr
chmod 777 /etc/wifiMgr/config
/etc/init.d/wifiMgr enable
/etc/init.d/wifiMgr start


DONE!



##################
#     USAGE      #
##################

The script will start at boot, and check the network availability every 60 seconds, by issuing several pings to google.com.
If all fail, it will trigger the network scan and reconfigure the network.

You should edit the file /etc/wifiMgr/config
The order in that file makes a difference: The script will parse the file and configure the first network found.
That means that "net1" has preference over "net2", and so on.

The config file needs three variables for each network:

net1_ssid="WIFI1"
net1_encrypt="psk2"
net1_key="Wifi12345678"

To create new networks, just create new "net2", "net3" and so on:

net2_ssid="WIFI2"
net2_encrypt="psk"
net2_key="Wifi2pass"

net3_ssid="WIFI3"
net3_encrypt="psk2"
net3_key="qwerty1234"


IMPORTANT NOTE:
Remeber to PUT dashes ("") and DO NOT put spaces between the variable name, the "=" and the variable value.
Examples of what not to do:
net1_ssid=WIFI1
net1_ssid ="WIFI1"
net1_ssid = "WIFI1"
net1_ssid= "WIFI1"

The script would work in an impredictable way if you don't respect the format.

There is a limit of 99 networks, the script will stop searching if it reaches the "net99", then return to the network check loop.
I don't think anybody has 99 wifi networks seen on his home!


SOME NOTES:

When the script finds a wireless network, it configures the interface and restarts the networking system.
After 20 seconds, it checks for internet availability even if the network was found.
If it fails, it discards the changes and continues searching from the point it left before.
Example: It finds "net1", but "net1" has no internet. Then it returns to the networks search, but looking for "net2".

In the case that a "netX" ssid variable is blank or doesn't exist, it assumes that it's the end of the file and the search is cancelled.
However, the script will keep running, so after 30 seconds it will check the network again.


You can edit the checking intervals by editing the variables inside the config file:

# Background internet connection checking interval
ConnCheckTimer=60

# After new network is set, time to wait for network to establish, before checking if it's working
NewConnCheckTimer=25

Also, you can set a random wlan MAC on each boot by changing the line:
randMac="0"

to

randMac="1"


==================================================================
At any moment, you can force a network scan (ex. your preferred network came back).
Just type:

wifiMgr.sh --force

It will scan and search the available networks and put the first available that it finds inside of the config file.



Also, you can force a scan and try to connect to a specific network:

wifiMgr.sh --force 5

It will try to connect to the network correspoding to "net5_ssid"

It will output the result: if it wasn't found, if it failed to connect, or it sucessfully connected.




####################
#  IS IT WORKING?  #
####################

==================================================================

Ensure that it's running in the background:

Run "ps -aux". You should see the script running:

25718 root      1520 S    {wifiMgr.sh} /bin/sh /usr/bin/wifiMgr.sh

==================================================================

Run "logread -f" to see the script output. It should be like this:


Sep  4 15:13:12 OpenWrt user.notice root: WifiMgr: Checking network...
Sep  4 15:13:16 OpenWrt user.notice root: WifiMgr: Network OK
Sep  4 15:13:46 OpenWrt user.notice root: WifiMgr: Checking network...
Sep  4 15:13:50 OpenWrt user.notice root: WifiMgr: Network OK

==================================================================

If the network came unavailable, it should output this:


Sep  4 15:14:20 OpenWrt user.notice root: WifiMgr: Checking network...
Sep  4 15:14:20 OpenWrt user.notice root: WifiMgr: Network failed. Starting network change...
Sep  4 15:14:20 OpenWrt user.notice root: WifiMgr: Performing network scan...
...
(Various messages about network initialization / setup)
...
Sep  4 15:14:21 OpenWrt user.notice root: WifiMgr: WifiMgr: Searching available networks...
Sep  4 15:14:21 OpenWrt user.notice root: WifiMgr: WLAN1662 network found. Applying settings..
...
(Various messages about network initialization / setup)
...
Sep  4 15:14:41 OpenWrt user.notice root: WifiMgr: Checking connectivity...
Sep  4 15:14:45 OpenWrt user.notice root: WifiMgr: Internet working! Searching ended