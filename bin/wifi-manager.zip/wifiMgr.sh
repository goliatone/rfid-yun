#!/bin/sh
. /etc/wifiMgr/config


randMacAddr()
{

	 macaddr=$(dd if=/dev/urandom bs=1024 count=1 2>/dev/null|md5sum|sed 's/^\(..\)\(..\)\(..\)\(..\)\(..\)\(..\).*$/00:\2:\3:\4:\5:01/')
	uci set wireless.@wifi-iface[0].macaddr="$macaddr"
	uci commit wireless
	/etc/init.d/network restart

}


NetStatus()
{
	logger WifiMgr: Checking network...
	net=$(ping google.es -c5 |grep "time=")
	if [ "$net" ]; then
		logger WifiMgr: Network OK
                #got ping response!
                return
	else
		logger WifiMgr: Network failed. Starting network change...
		NetChange
	fi
}



NetChange()
{
	logger WifiMgr: Performing network scan...
        scanres=
        ifconfig wlan0 down
        iw phy phy0 interface add scan0 type station
        ifconfig scan0 up

        while [ "$scanres" = "" ]; do
                #Sometimes it shows nothing, so better to ensure we did a correct scan
                scanres=$(iw scan0 scan|grep SSID)
        done

        iw dev scan0 del
        ifconfig wlan0 up
        killall -HUP hostapd
	logger WifiMgr: WifiMgr: Searching available networks...
	
	if [ "$1" ]; then
		ssid=net"$1"_ssid
		eval ssid=\$$ssid
		echo Trying to connect to network "$1"":    $ssid"
		n=$(expr "$1" - "1")
	else
        	n=0
        fi
        
        while [ "1" ]; do
                n=$(expr "$n" + "1")

                if [ "$n" = "99" ]; then
                                #too much counts. Crazy wireless count, breaking loop!
                                break
                fi

                ssid=net"$n"_ssid
                encrypt=net"$n"_encrypt
                key=net"$n"_key

                eval ssid=\$$ssid
                eval encrypt=\$$encrypt
                eval key=\$$key
                
                if [ "$ssid" = "" ]; then
                                #ssid not existing or empty. Assume it's the end of the wlist file
                                break
                fi
                echo RED: $ssid
                echo CLAVE: $key
                echo SEGURIDAD: $encrypt
                

                active=$(echo $scanres | grep " $ssid ">&1 )
                if [ "$active" ]; then
                	if [ "$1" ]; then
                		echo Network found. Connecting...
                	fi
			logger WifiMgr: "$ssid" network found. Applying settings..
                        uci set wireless.@wifi-iface[0].ssid="$ssid"
                        uci set wireless.@wifi-iface[0].encryption="$encrypt"
                        uci set wireless.@wifi-iface[0].key="$key"
                        uci commit wireless
                        /etc/init.d/network restart
                        
                        #wait some seconds for everything to connect and configure
                        sleep $NewConnCheckTimer
			logger WifiMgr: Checking connectivity...

                        #check for internet connection, 5 ping sends
                        net=$(ping google.es -c5 |grep "time=")
                        if [ "$net" ]; then
				#got ping response!
				logger WifiMgr: Internet working! Searching ended
				if [ "$1" ]; then
					echo Sucess!
				fi
                        	break
                        fi
                        if [ "$1" ]; then
                        	echo Connection failed!
                        	break
                        fi
			logger WifiMgr: Failed! Searching next available network...
                fi
        done
}

if [ "$1" = "" ]; then
	echo "No arguments supplied"

elif [ "$1" = "--force" ]; then
	NetChange $2

elif [ "$1" = "--daemon" ]; then
	
	if [ "$randMac" = "1" ]; then
		randMacAddr	
	fi
	NetChange
	
	while [ "1" ]; do
		sleep $ConnCheckTimer
        	NetStatus
	done

else
	echo "Wrong arguments"
fi

